<?php

declare(strict_types=1);

/**
 * Local configuration — XAMPP development machine.
 *
 * This file is git-ignored (.gitignore) and shipped only with the local setup
 * package. bootstrap.php merges it recursively over config/*.php, so any key
 * omitted here keeps its default.
 *
 * XAMPP defaults: MySQL/MariaDB on 127.0.0.1:3306 with user `root` and an empty
 * password. Change `database` here — never in the tracked config files — if the
 * database is created under another name.
 */

return [
    'app' => [
        'env' => 'local',
        'debug' => true,
        // Base URL of the project as Apache serves it from htdocs:
        // http://localhost/SyncClass/ (and http://localhost/syncclass/ on
        // Windows, where the path is case-insensitive). APP_URL overrides it
        // for a preview server or a virtual host whose document root is
        // already public/, where the /SyncClass prefix must not appear.
        'url' => getenv('APP_URL') ?: 'http://localhost/SyncClass',
    ],

    'database' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'anth04_SyncClass',
        'username' => 'root',
        'password' => '',
    ],

    // Email stays off until SMTP is configured (Phase 14); notifications are
    // written in-app regardless.
    'mail' => [
        'enabled' => false,
    ],
];
